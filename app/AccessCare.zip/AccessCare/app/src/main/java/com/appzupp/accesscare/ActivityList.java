package com.appzupp.accesscare;

import android.os.Bundle;

import com.appzupp.accesscare.util.IActivityList;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

public class ActivityList extends AppCompatActivity implements IActivityList {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
    }

    @Override
    public void createNewActivity(String activityName, String activityInstructions, boolean activityStatus) {

    }
}