package com.appzupp.accesscare.util;

public interface IActivityList {
    void createNewActivity(String activityName,
                           String activityInstructions,
                           boolean activityStatus);
}
