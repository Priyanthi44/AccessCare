package com.appzupp.accesscare.model;

import com.google.firebase.firestore.IgnoreExtraProperties;
@IgnoreExtraProperties
public class Activity {
    private String activity_name;
    private String instructions;
    private boolean activity_status;

    public Activity(String activity_name,String instructions,boolean activity_status ){
        this.activity_name=activity_name;
        this.instructions=instructions;
        this.activity_status=activity_status;
    }

    public Activity(){

    }

    public String getActivity_name(){
        return this.activity_name;
    }

    public void setActivity_name(String activity_name) {
        this.activity_name = activity_name;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public boolean isActivity_status() {
        return activity_status;
    }

    public void setActivity_status(boolean activity_status) {
        this.activity_status = activity_status;
    }
}
